#!/bin/bash
param=$1
version=1.2.3

if [ ! -z $param ]; then
    if [ $param = "install" ]; then
        echo "type: install"
        sudo mkdir -p /usr/local/lib/std_cout
        sudo mkdir -p /usr/local/lib/cmake/std_cout
        sudo mkdir -p /usr/local/include/std_cout

        sudo mv ./libstd_cout.so /usr/local/lib/std_cout
        sudo mv ./std_coutConfig.cmake /usr/local/lib/cmake/std_cout
        sudo mv ./std_coutConfigVersion.cmake /usr/local/lib/cmake/std_cout
        sudo mv ./std_coutTargets.cmake /usr/local/lib/cmake/std_cout
        sudo mv ./std_coutTargets-noconfig.cmake /usr/local/lib/cmake/std_cout
        sudo mv ./std_cout.hpp /usr/local/include/std_cout
        sudo mv ./std_cout.tpp /usr/local/include/std_cout

        echo "installation done:)"
    elif [ $param = "tar" ];then
        echo "type: tar"
        if [ ! -d "../build" ]; then
            echo "build directory is not found"
            exit
        fi
        mkdir std_cout_install
        cp ../build/libstd_cout.so std_cout_install/
        cp ../build/std_coutConfig.cmake std_cout_install/
        cp ../build/std_coutConfigVersion.cmake std_cout_install/
        cp ../build/CMakeFiles/Export/lib/cmake/std_cout/std_coutTargets.cmake std_cout_install/
        cp ../build/CMakeFiles/Export/lib/cmake/std_cout/std_coutTargets-noconfig.cmake std_cout_install/
        cp ../include/std_cout.hpp std_cout_install/
        cp ../include/std_cout.tpp std_cout_install/
        cp ./gether.sh std_cout_install/

        ### create a README.md
        filename=std_cout_install/README.md
        cat > $filename << END_LABEL
Once a tar file is extracted, go to the 'std_cout_install' directory, then please, execute a script.
\`\`\`
./gether.sh install
\`\`\`
You may remove the 'std_cout_install' directory after it's installed.
END_LABEL
# if indent is not fit but it's important for END_LABEL to start with the first line.

        tar Jcvfp std_cout_v${version}_debian11_arm64.tar.xz std_cout_install/*
        rm -rf ./std_cout_install
        
        echo "tar Done:)"

    else 
        echo "wrong parameter"
        
    fi
    exit
fi

echo "tar or install"


#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "std_cout::std_cout" for configuration ""
set_property(TARGET std_cout::std_cout APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(std_cout::std_cout PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/std_cout/libstd_cout.so"
  IMPORTED_SONAME_NOCONFIG "libstd_cout.so"
  )

list(APPEND _cmake_import_check_targets std_cout::std_cout )
list(APPEND _cmake_import_check_files_for_std_cout::std_cout "${_IMPORT_PREFIX}/lib/std_cout/libstd_cout.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)



include("${CMAKE_CURRENT_LIST_DIR}/std_coutTargets.cmake")

set(STD_COUT_LIBRARIES std_cout::std_cout)
set(STD_COUT_INCLUDE_DIR "/usr/local/include/std_cout")
